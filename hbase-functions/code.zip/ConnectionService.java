package com.jl.hbasetraining;

import org.springframework.stereotype.Service;

@Service
public class ConnectionService {

}
