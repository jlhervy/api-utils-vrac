package com.jl.hbasetraining

object test {
  def main(args: Array[String]): Unit = {
    println("Hello, world!")
  }
}
